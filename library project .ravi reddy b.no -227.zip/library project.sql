create database library_data;
use library_data;

-- create table for publisher--
create table data_publisher(
publisher_PublisherName varchar(255) primary key,
publisher_PublisherAddress varchar(255),
publisher_PublisherPhone varchar(255)
);

-- create table for borrower--
create table data_borrower(
borrower_CardNo int primary key auto_increment,
borrower_BorrowerName varchar(255),
borrower_BorrowerAddress varchar(255),
borrower_BorrowerPhone varchar(255)
);


-- create table for books--
create table data_books(
book_BookID int primary key auto_increment,
book_Title varchar(255),
book_PublisherName varchar(255) not null,
foreign key( book_publishername) references data_publisher(publisher_publishername) on delete cascade );


-- create table for authors--
create table data_authors(
book_authors_AuthorID int primary key auto_increment not null,
book_authors_BookID int not null ,
book_authors_AuthorName varchar(255),
foreign key (book_authors_BookID) references data_books(book_BookID) on delete cascade
);

-- create table for library_branch--
create table data_library_branch(
library_branch_id int primary key auto_increment,
library_branch_BranchName varchar(255),
library_branch_BranchAddress varchar(255)
);

-- create table for book_copies--
create table data_book_copies(
book_copies_copiesID int primary key auto_increment,
book_copies_BookID int not null,
book_copies_BranchID int not null,
book_copies_No_Of_Copies int,
foreign key (book_copies_BookID) references data_books(book_bookID) on delete cascade,
foreign key (book_copies_BranchID) references data_library_branch(library_branch_id) on delete cascade
);


-- create table for book_loans--
create table data_book_loans(
 book_loans_LoansID int primary key auto_increment,
book_loans_BookID int not null,
book_loans_BranchID int not null,
book_loans_CardNo int not null,
book_loans_DateOut varchar(255),
book_loans_DueDate varchar(255),
foreign key (book_loans_BookID)  references data_books(book_BookID) on delete cascade,
foreign key (book_loans_BranchID) references data_library_branch(library_branch_id) on delete cascade,
foreign key (book_loans_cardNo) references data_borrower(borrower_CardNo) on delete cascade
); 

select * from data_authors;
select * from data_book_copies;
select * from data_book_loans;
select * from data_books;
select * from data_borrower;
select * from data_library_branch;
select * from data_publisher;


-- 1. How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"?--
select count(*)
from data_books,data_library_branch,data_book_copies
where book_title ='The Lost Tribe' and library_branch_BranchName = 'Sharpstown';

-- 2.How many copies of the book titled "The Lost Tribe" are owned by each library branch?
select count(*)
from data_books,data_library_branch,data_book_copies
where book_title ='The Lost Tribe' ;

-- 3.Retrieve the names of all borrowers who do not have any books checked out.
select * from data_borrower;
select * from data_book_loans;

select bo.borrower_borrowername , lo.book_loans_DateOut
from data_borrower as bo
left join data_book_loans as lo
on bo.borrower_cardno = lo.book_loans_CardNo
where lo.book_loans_DateOut is null;


-- 4.For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, 
-- the borrower's name,and the borrower's address. --
select * from data_book_loans;
select * from data_library_branch;
select * from data_borrower;
select * from data_books;

select book_title,borrower_BorrowerName,borrower_BorrowerAddress
from data_books,data_borrower,data_library_branch,data_book_loans
where library_branch_BranchName = 'Sharpstown' and book_loans_DueDate = '2/3/18'
order by book_title;

-- 5.For each library branch, retrieve the branch name and the total number of books loaned out from that branch.
select * from data_library_branch;
select * from data_book_loans;
select br.library_branch_BranchName,count(br.library_branch_BranchName) as total_num
from data_library_branch as br
cross join data_book_loans as lo
on br.library_branch_id=lo.book_loans_BranchID
group by br.library_branch_BranchName;

-- 6.Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out.
select * from data_borrower;
select * from data_book_loans;

select 
tb.borrower_BorrowerName,
tb.borrower_BorrowerAddress,
nb.book_loans_CardNo,count(*) as total_num
from data_borrower as tb
cross join data_book_loans as nb
on tb.borrower_CardNo=nb.book_loans_CardNo
group by tb.borrower_cardno
having count(*)  > 5;

-- 7.For each book authored by "Stephen King", 
-- retrieve the title and the number of copies owned by the library branch whose name is "Central".

select * from data_authors;
select * from data_library_branch;
select * from data_books;
select * from data_book_copies;

select book_title,book_copies_No_Of_Copies
from data_authors
join data_books
join data_book_copies
join data_library_branch
where book_authors_AuthorName ='Stephen King' and library_branch_BranchName = 'Central';




